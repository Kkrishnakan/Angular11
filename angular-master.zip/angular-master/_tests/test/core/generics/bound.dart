/// Serves as a generic type parameter bound.
///
/// This is intentionally declared in a separate target to test the workaround
/// for b/111800117.
class Bound {}
