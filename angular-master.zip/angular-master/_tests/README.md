This package is all the unit and component tests for `package:angular`. They
are maintained here in order to avoid declaring circular dependencies between
`angular` and `angular_test`, as well as adding private testing infrastructure.
