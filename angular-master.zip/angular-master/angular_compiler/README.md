Tooling for compiling [AngularDart](https://pub.dev/packages/angular).

See https://github.com/angulardart for current updates on this project.
