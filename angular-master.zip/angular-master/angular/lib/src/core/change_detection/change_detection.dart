export 'package:angular/src/meta.dart'
    show ChangeDetectionStrategy, ChangeDetectorState;

export 'change_detector_ref.dart'
    show
        ChangeDetectorRef,
        DeprecatedChangeDetectorRef,
        DeprecatedDetectChanges;
