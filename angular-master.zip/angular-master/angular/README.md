See https://github.com/angulardart for current updates on this project.
